# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import re
from sklearn.preprocessing import OneHotEncoder,LabelEncoder
data=pd.read_csv('data.csv')
data = data.iloc[:,[4,5,7,8,9,13,14,15,17,18,19,23,24,25,26]]

y=data.iloc[:,0:1].values
x=data.iloc[:,1:].values


def rmCom(cNum):
    for item in range(len(x[:,0])):
        if x[item,cNum]==" ":
                x[item,cNum]=500000
        else:
            x[item,cNum] = int((re.sub('[$,]','',x[item,cNum])))
      
rmCom(0)
rmCom(11)
rmCom(12)


# to convert currencies to dollar
from currency_converter import CurrencyConverter
c = CurrencyConverter()

cNum = 10

for i in range(len(x[:,0])):
        if x[i,10][0] != '$':
            if x[i,10][0] =='£':
                x[i,10]=c.convert(int(x[i,cNum][1:].replace(",",'')),"GBP","USD")
            elif x[i,10][0] == '€':
                x[i,10]=c.convert(int(x[i,cNum][1:].replace(",",'')),"EUR","USD")
            elif x[i,10][0] == ' ':
                x[i,10]=500000
            else:
                if x[i,cNum][:3] != "FRF":
                    if x[i,cNum][:3] != "DEM":
                        if x[i,cNum][:3] != "RUR":
                            x[i,10]=c.convert(int(x[i,cNum][4:].replace(",",'')),x[i,cNum][:3],"USD")
                        else:
                            x[i,cNum]=int(re.sub('[RUR ]','',x[i,cNum]).replace(',',''))
                    else:
                        x[i,cNum]=int(re.sub('[DEM ]','',x[i,cNum]).replace(',',''))
                else:
                    x[i,cNum]=int(re.sub('[FRF ]','',x[i,cNum]).replace(',',''))
        else:
            x[i,cNum]=int(re.sub('[$,]','',x[i,cNum]))

# label encoding
l_encoder=LabelEncoder()
fit_list=[1,2,3,4,5,6,7,8,9,13]

for items in fit_list:
        x[:,items]=l_encoder.fit_transform(x[:,items])

# one hot encoding
oh_encoder=OneHotEncoder(categorical_features=fit_list)
x=oh_encoder.fit_transform(x).toarray()

# test train data
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2)

#training model using linear regression
from sklearn.linear_model import LinearRegression
MLR = LinearRegression()
MLR.fit(x_train,y_train)
y_pred = MLR.predict(x_test)        
score = MLR.score(x_test,y_pred)        
 